-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-02-2022 a las 12:19:11
-- Versión del servidor: 10.4.22-MariaDB
-- Versión de PHP: 8.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `conexionnetbeans`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `localidad`
--

CREATE TABLE `localidad` (
  `NumLoc` int(11) NOT NULL,
  `NomLoc` varchar(20) DEFAULT NULL,
  `ProvLoc` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `IdProd` int(11) NOT NULL,
  `Nombre` varchar(20) NOT NULL,
  `Precio` int(11) NOT NULL,
  `Categoria` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`IdProd`, `Nombre`, `Precio`, `Categoria`) VALUES
(1, 'Leche', 50, 'lacteo'),
(2, 'Queso', 200, 'lacteo'),
(3, 'Yogur', 186, 'lacteo'),
(4, 'Leche de avena', 130, 'lacteofalso'),
(5, 'Helado de nata', 210, 'lacteo'),
(6, '', 0, ''),
(7, '', 0, ''),
(9, '', 0, ''),
(11, '', 0, ''),
(12, '', 0, ''),
(13, 'test', 0, 'test2'),
(14, '', 0, ''),
(15, '', 0, ''),
(17, '', 0, ''),
(18, '', 0, ''),
(19, '', 0, ''),
(20, '', 0, ''),
(21, '', 0, ''),
(22, '', 0, ''),
(23, '', 0, ''),
(24, '', 0, ''),
(25, '', 0, ''),
(26, '', 0, ''),
(27, '', 0, ''),
(28, '', 0, ''),
(29, '', 0, ''),
(30, '', 0, ''),
(31, '', 0, ''),
(32, '', 0, ''),
(33, '', 0, ''),
(34, '', 0, ''),
(35, '', 0, ''),
(36, '', 0, ''),
(37, '', 0, ''),
(38, '', 0, ''),
(39, '', 0, ''),
(40, '', 0, ''),
(41, '', 0, ''),
(42, '', 0, ''),
(43, '', 0, ''),
(88, 'Salchichon', 120, 'embutido'),
(90, 'Mortadela', 300, 'PseudoSiciliana SA');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `Idprov` int(11) NOT NULL,
  `Idprod` int(11) NOT NULL COMMENT 'Foranea de productos',
  `NomProv` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`Idprov`, `Idprod`, `NomProv`) VALUES
(10, 1, 'Lecheria chema SL'),
(20, 1, 'Lecheria Mauro SL'),
(30, 1, 'Lecheria Alberto SA'),
(44, 5, 'Hacendado SA'),
(55, 5, 'Gelatto Di Italia Ignacio SL'),
(77, 2, 'Fomaggio Italiano Samuel SA'),
(420, 88, 'Casa Tarradellas S.A.'),
(444, 3, 'Hacendado SA'),
(999, 3, 'Yogur Griego GiregoSL');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `localidad`
--
ALTER TABLE `localidad`
  ADD PRIMARY KEY (`NumLoc`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`IdProd`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`Idprov`),
  ADD KEY `IdProductoprovprods` (`Idprod`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD CONSTRAINT `IdProductoprovprods` FOREIGN KEY (`Idprod`) REFERENCES `productos` (`IdProd`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
